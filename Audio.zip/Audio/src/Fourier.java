// program: Fourier.java
// author: Amarpreet Kaur
// course: CS 427
// date: 2018/10/29
// assignment #2
// description: This program implements the DFT algorithm

public class Fourier {
	public static double[] discreteFT(double[]fdata, int N){
		double X[] = new double[2*N];
		double omega;
		//real and imaginary value positions
		int ki, kr, n;
		//calculating the value of omega
		omega = 2.0*Math.PI/N;

		for(int k=0; k<N; k++) {
			//Initializing real and imaginary value positions
			kr = 2*k;
			ki = 2*k + 1;
			X[kr] = 0.0;
			X[ki] = 0.0;
			//DFT formula to calculate the Fourier Transform
			for(n=0; n<N; ++n) {
				X[kr] += fdata[2*n]*Math.cos(omega*n*k) + fdata[2*n+1]*Math.sin(omega*n*k);
				X[ki] += -fdata[2*n]*Math.sin(omega*n*k) + fdata[2*n+1]*Math.cos(omega*n*k);
			}
		}
		//scaling the output
		for(int k=0; k<N; ++k) {
			X[2*k] /= N;
			X[2*k + 1] /= N;
		}
		//returning the final values
		return X;
	}
}


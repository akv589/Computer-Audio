 
// program: TestDFT.java
// author: Amarpreet Kaur
// course: CS 427
// date: 2018/10/29
// assignment #2
// description: This program implements the DFT algorithm

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * @author amarpreet
 *
 */
public class TestDFT {
	public static void main(String args[]) throws IOException {
		//total number of samples 
		int N = 512;
		//Sampling rate
		double T = 10.0;
		//sampling time
		double fk;
		
		//reading amplitude values from the file and storing in an Array List
		BufferedReader in = new BufferedReader(new FileReader("C:\\Users\\amarpreet\\Downloads\\spectrum.txt"));
		List<String> amplitudesDB = new ArrayList<String>();
		String line;
		while(( line = in.readLine()) != null) {
			amplitudesDB.add(line);
		}
		String temp[] = new String[amplitudesDB.size()];
		temp= amplitudesDB.toArray(temp);
		
		double amplitude[] = new double[temp.length];
		for(int i=0;i<temp.length;i++) {
			amplitude[i]= Double.parseDouble(temp[i]);
			//converting decibel to amplitude
			double b =  (amplitude[i]/20);
			amplitude[i] = Math.pow(10,b);
		}
		//Frequency data stored in array of size 2*N so as to put real and imaginary values at every alternate positions
		double fdata[] = new double[2* N];
		for (int i = 0; i < N-1; ++i) {
			fdata[2 * i] = amplitude[i];
			fdata[2 * i + 1] = 0.0;
		}
		//data is passed to compute DFT along with N as parameters
		double X[] = Fourier.discreteFT(fdata, N);
		//printing the real and imaginary parts along with sampling time
		for (int k = 0; k < N; ++k) {
			fk = k / T;
			System.out.println("f["+k+"] = "+fk+" Real["+k+"] = "+X[2*k]+ " Imag["+k+"] = "+X[2*k + 1]) ;
		}
	}
}
